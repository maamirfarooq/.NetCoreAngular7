export class RoleModel {
    public RoleId : number;
    public RoleName: string;
    public Status: boolean;
    public  RolePolicy:string;
    public  RoleMember:string;
    public  RoleDescription:string;
}