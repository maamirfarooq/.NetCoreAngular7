export class UserModel 
{
    public UserId: number;
    public UserName: string;
    public FirstName: string;
    public LastName: string;
    public TypeOfUser: boolean;
    public Password: string;
    public Status: boolean;
    
}