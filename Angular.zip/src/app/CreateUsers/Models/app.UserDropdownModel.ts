export class UserDropdownModel 
{
    public UserId: number;
    public UserName: string;
}