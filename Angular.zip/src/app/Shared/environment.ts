/** This file in future not longer referenced, apiEndPoint Reference from "environment/environment" */

export const environment =
{
    production: false,
    apiEndpoint: 'http://localhost:49749'
  };

