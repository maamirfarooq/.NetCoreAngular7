import { Component} from '@angular/core';

@Component({
    templateUrl:'./app.UserDashboardComponent.html'
})

export class UserDashboardComponent
{

}