export class GroupModel {
    public GroupId : number;
    public GroupName: string;
    public GroupDescription:string;
    public Status: boolean;
}