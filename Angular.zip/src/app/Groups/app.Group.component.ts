import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { GroupModel } from './Model/app.GroupModel';
import { GroupService } from './Services/app.Group.Service';

@Component({
    templateUrl : './app.Group.html',
    styleUrls: ['../Content/vendor/bootstrap/css/bootstrap.min.css',
    '../Content/vendor/metisMenu/metisMenu.min.css',
    '../Content/dist/css/sb-admin-2.css',
    '../Content/vendor/font-awesome/css/font-awesome.min.css'
]
})

export class GroupComponent
{
    private _groupService;
    GroupModel : GroupModel = new GroupModel();
    output: any;

    constructor(private _Route: Router, groupService :GroupService ){
        this._groupService = groupService;
    }

    onSubmit() 
    {
        this._groupService.AddGroup(this.GroupModel).subscribe(
            response => {
            this.output = response
            if (this.output.StatusCode == "409") {
                alert('Group Already Exists');
            }
            else if (this.output.StatusCode == "200") {
                alert('Group Saved Successfully');
                this._Route.navigate(['/Group/All']);
            }
            else {
                alert('Something Went Wrong');
            }
        });
    }

}