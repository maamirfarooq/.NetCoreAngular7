﻿using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebGYM.Interface;
using WebGYM.Models;
using WebGYM.ViewModels;

namespace WebGYM.Concrete
{
   public class UserGroupRoleConcrete: IUserGroupRole
    {
        private readonly DatabaseContext _context;
        private readonly IConfiguration _configuration;

        public UserGroupRoleConcrete(DatabaseContext context, IConfiguration config)
        {
            _context = context;
            _configuration = config;
        }

        public bool AssignUserGroupRole(UserGroupRole userGroupRole)
        {
            _context.Add(userGroupRole);
            var result = _context.SaveChanges();
            if (result > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool CheckUserGroupRoleExists(UserGroupRole userGroupRole)
        {
            var result = (from userrole in _context.UsersInRoles
                          where userrole.UserRolesId == userrole.UserRolesId && userrole.RoleId == userGroupRole.RoleId
                          select userrole).Count();

            return result > 0 ? true : false;
        }

        public List<UserGroupRoleViewModel> GetAssignUserGroup()
        {     
            var result = (from usertb in _context.UserGroupRole
                          join Role in _context.Role on usertb.RoleId equals Role.RoleId
                          join Group in _context.Group on usertb.UserGroupRuleId equals Group.GroupId
                          select new UserGroupRoleViewModel()
                          {
                              RoleName = Role.RoleName,
                              RoleId = usertb.RoleId,
                              GroupName = Group.GroupName,
                              GroupId = usertb.GroupId,

                              UserGroupRuleId = usertb.UserGroupRuleId

                          }).ToList();
            return result;
        }

        public bool RemoveUserGroupRole(UserGroupRole userGroupRole)
        {
            var group = (from userrole in _context.UserGroupRole
                        where userrole.UserGroupRuleId == userGroupRole.UserGroupRuleId && userrole.RoleId == userGroupRole.RoleId
                        select userrole).FirstOrDefault();
            if (group != null)
            {
                _context.UserGroupRole.Remove(group);
                var result = _context.SaveChanges();

                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
    }
}
