﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebGYM.Interface;
using WebGYM.Models;
using WebGYM.ViewModels;

namespace WebGYM.Concrete
{
    class UserGroupConcrete: IUserGroup
    {
        private readonly DatabaseContext _context;
        private readonly IConfiguration _configuration;

        public UserGroupConcrete(DatabaseContext context, IConfiguration config)
        {
            _context = context;
            _configuration = config;
        }

        public bool AssignUserGroup(UserGroup userGroup)
        {
            _context.Add(userGroup);
            var result = _context.SaveChanges();
            if (result > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool CheckUserGroupExists(UserGroup userGroups)
        {
            var result = (from UserGroup in _context.UserGroup
                          where userGroups.UserGroupId == userGroups.GroupId && userGroups.UserGroupId == userGroups.UserId
                          select userGroups).Count();

            return result > 0 ? true : false;
        }

        public List<AssignUserGroupViewModel> GetAssignUserGroup()
        {
           var result = (from usertb in _context.UserGroup
                          join Group in _context.Group on usertb.GroupId equals Group.GroupId
                          join user in _context.Users on usertb.UserId equals user.UserId
                          select new AssignUserGroupViewModel()
                          {
                              GroupName = Group.GroupName,
                              GroupId = usertb.GroupId,
                              UserName = Group.GroupName,
                              UserId = usertb.UserId,
                              UserGroupId = usertb.UserGroupId

                          }).ToList();

            return result;
        }

        public bool RemoveUserGroup(UserGroup userGroup)
        {
            var role = (from UserGroup in _context.UserGroup
                        where userGroup.UserGroupId == userGroup.GroupId && userGroup.UserGroupId == userGroup.UserId
                        select userGroup).FirstOrDefault();
            if (role != null)
            {
                _context.UserGroup.Remove(role);
                var result = _context.SaveChanges();

                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
    }
}
