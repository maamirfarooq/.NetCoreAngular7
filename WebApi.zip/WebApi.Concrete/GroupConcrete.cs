﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using Microsoft.Extensions.Configuration;
using WebGYM.Interface;
using WebGYM.Models;

namespace WebGYM.Concrete
{
    public class GroupConcrete : IGroup
    {
        private readonly DatabaseContext _context;
        private readonly IConfiguration _configuration;

        public GroupConcrete(DatabaseContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }



        public bool ChecKGroupExits(string GroupName)
        {
            var result = (from Group in _context.Group
                          where Group.GroupName == GroupName
                          select Group).Count();

            return result > 0 ? true : false;
        }

        public bool DeleteGroup(int GroupId)
        {
            var groupdata = (from Group in _context.Group
                            where Group.GroupId == GroupId
                            select Group).FirstOrDefault();

            if (groupdata != null)
            {
                _context.Group.Remove(groupdata);
                var result = _context.SaveChanges();

                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public List<Group> GetAllGroup()
        {
            var result = (from Group in _context.Group
                          select Group).ToList();

            return result;
        }

        public Group GetGroupbyId(int GroupId)
        {
            var result = (from Group in _context.Group
                          where Group.GroupId == GroupId
                          select Group).FirstOrDefault();

            return result;
        }

        public void InsertGroupe(Group group)
        {
            _context.Group.Add(group);
            _context.SaveChanges();
        }

        public bool UpdateGroup(Group group)
        {
            _context.Entry(group).Property(x => x.Status).IsModified = true;
            var result = _context.SaveChanges();
            if (result > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
