﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebGYM.Models;
using Group = WebGYM.Models.Group;

namespace WebGYM.Concrete
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions<DatabaseContext> options) : base(options)
        {

        }

        public DbSet<Role> Role { get; set; }
        public DbSet<Users> Users { get; set; }
        public DbSet<UsersInRoles> UsersInRoles { get; set; }
        public DbSet<Group> Group{ get;set;}
        public DbSet<UserGroup> UserGroup { get; set; }
        public DbSet<UserGroupRole> UserGroupRole { get; set; }
    }
}
