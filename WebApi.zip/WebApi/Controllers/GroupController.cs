﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebGYM.Interface;
using WebGYM.Models;
using WebGYM.ViewModels;

namespace WebGYM.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class GroupController : ControllerBase
    {
        private readonly IGroup _group;

        public GroupController(IGroup group)
        {
            _group = group;
        }

        // GET: api/CreateGroup
        [HttpGet]
        public IEnumerable<Group> Get()
        {
            try
            {
                return _group.GetAllGroup();
            }
            catch (Exception)
            {

                throw;
            }
        }

        // GET: api/CreateGroup/5
        [HttpGet("{id}", Name = "GetGroup")]
        public Group Get(int id)
        {
            try
            {
                return _group.GetGroupbyId(id);
            }
            catch (Exception)
            {

                throw;
            }
        }

        // POST: api/CreateGroup
        [HttpPost]
        public HttpResponseMessage Post([FromBody] GroupViewModel groupViewModel)
        {

            try
            {
                if (ModelState.IsValid)
                {
                    if (_group.ChecKGroupExits(groupViewModel.GroupName))
                    {
                        var response = new HttpResponseMessage()
                        {
                            StatusCode = HttpStatusCode.Conflict
                        };

                        return response;
                    }
                    else
                    {
                        var tempgroup = AutoMapper.Mapper.Map<Group>(groupViewModel);

                        _group.InsertGroupe(tempgroup);

                        var response = new HttpResponseMessage()
                        {
                            StatusCode = HttpStatusCode.OK
                        };

                        return response;
                    }
                }
                else
                {
                    var response = new HttpResponseMessage()
                    {

                        StatusCode = HttpStatusCode.BadRequest
                    };

                    return response;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        // PUT: api/CreateGroup/5
        [HttpPut("{id}")]
        public HttpResponseMessage Put(int id, [FromBody] RoleViewModel roleViewModel)
        {
            try
            {
                var tempgroup = AutoMapper.Mapper.Map<Group>(roleViewModel);
                _group.UpdateGroup(tempgroup);

                var response = new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK
                };

                return response;
            }
            catch (Exception)
            {
                var response = new HttpResponseMessage()
                {

                    StatusCode = HttpStatusCode.BadRequest
                };

                return response;

            }
        }

        // DELETE: api/DeletGroup/5
        [HttpDelete("{id}")]
        public HttpResponseMessage Delete(int id)
        {
            try
            {

                var result = _group.DeleteGroup(id);

                if (result)
                {
                    var response = new HttpResponseMessage()
                    {
                        StatusCode = HttpStatusCode.OK
                    };
                    return response;
                }
                else
                {
                    var response = new HttpResponseMessage()
                    {
                        StatusCode = HttpStatusCode.BadRequest
                    };
                    return response;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
        