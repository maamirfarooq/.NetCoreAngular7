﻿namespace WebGYM.ViewModels
{
    public class AssignUserGroupRoleViewModel
    {
        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public int UserGroupId { get; set; }
    }
}
