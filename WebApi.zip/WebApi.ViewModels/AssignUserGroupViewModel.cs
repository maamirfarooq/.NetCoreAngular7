﻿namespace WebGYM.ViewModels
{
    public class AssignUserGroupViewModel
    {
        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; }
        public int UserGroupId { get; set; }
    }
}
