﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebGYM.ViewModels
{
    public class UsersViewModel
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Enter UserName")]
        public string UserName { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        public bool TypeOfUser { get; set; }
        [Required(ErrorMessage = "Enter Password")]
        public string Password { get; set; }
        public bool Status { get; set; }
    }
}
