﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebGYM.ViewModels
{
   public class UserGroupRoleViewModel
    {
        public int UserGroupRuleId { get; set; }

        public int GroupId { get; set; }
        public string GroupName { get; set; }

        public int RoleId { get; set; }
        public string RoleName { get; set; }

    }
}
