﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebGYM.Models;
using WebGYM.ViewModels;

namespace WebGYM.Interface
{
   public interface IUserGroupRole
    {
        bool AssignUserGroupRole(UserGroupRole userGroupRole);
        bool CheckUserGroupRoleExists(UserGroupRole userGroupRole);
        bool RemoveUserGroupRole(UserGroupRole userGroupRole);
        List<UserGroupRoleViewModel> GetAssignUserGroup();
    }
}
