﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebGYM.Models;
using WebGYM.ViewModels;

namespace WebGYM.Interface
{
  public  interface IUserGroup
    {
        bool AssignUserGroup(UserGroup userGroup);
        bool CheckUserGroupExists(UserGroup userGroups);
        bool RemoveUserGroup(UserGroup userGroup);
        List<AssignUserGroupViewModel> GetAssignUserGroup();
    }
}
